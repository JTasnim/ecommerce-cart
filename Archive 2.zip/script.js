"use strict";

const items = ["Keyboard", "Mouse", "Printer", "Speaker"];
const price = [45, 30, 80, 60];
const itemNumber = [0, 0, 0, 0];
const totalAmount = 0;

// const map1 = array1.map(x => x * 2);
const parentEl = document.querySelector(".item-view");
const addCart = document.querySelector(".item-view");
const cartItem = document.querySelector(".cart-view");
const btnCart = document.querySelector(".cart");
const cashAmount = document.querySelector(".cash");

const listOfItem = function () {
  const markup = items
    .map(
      (arr, i) =>
        ` <li class="preview">
            <div>
              <p class="item">${arr}</p>
              <p class="price">Price $${price[i]}</p>
              <button class="add-item add-item-${i}">Add</button>
            </div>
        </li>
        `
    )
    .join("");
  parentEl.insertAdjacentHTML("afterbegin", markup);
};

listOfItem();

const addItemToCart = function (id) {
  const markup = `
      <li class="cart-preview cart-preview-${id}">
      <div>
        <div class="item-info">
          <span>${items[id]}</span>
          <span class="amount-${id}">x 1</span>
          <span class="price-${id}"> = ${price[id]}$</span>
        </div>
        <div class="count">
          <button class="btn-count incre-${id}">+</button>
          <button class="btn-count dec-${id}">-</button>
        </div>
      </div>
    </li>
  `;
  cartItem.insertAdjacentHTML("beforeend", markup);
};

const editText = function (id) {
  const value = itemNumber[id] + 1;
  const span_amount = document.querySelector(`.amount-${id}`);
  const span_price = document.querySelector(`.price-${id}`);
  span_amount.textContent = `x ${value}`;
  id = +id;
  //console.log(typeof value, typeof price[id], value, id);
  span_price.textContent = `= ${value * price[id]}$`;
};

const checkOut = function () {
  //const val = price.reduce((ecc, item) => (ecc += item));
  let val = 0;
  for (let i = 0; i < price.length; i++) {
    val += price[i] * itemNumber[i];
  }
  console.log(val);
  cashAmount.textContent = `Total ${val}$`;
};

addCart.addEventListener("click", function (e) {
  e.preventDefault();
  const btn = e.target.classList[1];
  if (!btn) return;
  const curr = btn[btn.length - 1];
  if (itemNumber[curr] === 0) {
    addItemToCart(curr);
    itemNumber[curr] += 1;
    checkOut();
  }
});

const editTextDecrement = function (id) {
  const value = itemNumber[id] - 1;
  const span_amount = document.querySelector(`.amount-${id}`);
  const span_price = document.querySelector(`.price-${id}`);
  span_amount.textContent = `x ${value}`;
  id = +id;
  //console.log(typeof value, typeof price[id], value, id);
  span_price.textContent = `= ${value * price[id]}$`;
};

btnCart.addEventListener("click", function (e) {
  e.preventDefault();
  const btn = e.target.classList[1];
  if (!btn) return;
  const curr = btn[btn.length - 1];
  if (btn[0] == "i") {
    editText(curr);
    itemNumber[curr] += 1;
  } else {
    editTextDecrement(curr);
    itemNumber[curr] -= 1;
    if (itemNumber[curr] === 0) {
      const delItem = document.querySelector(`.cart-preview-${curr}`);
      //const element = document.querySelector(".cart-preview");
      //console.log(delItem);
      delItem.innerHTML = "";
      delItem.style.paddingTop = "0px";
      delItem.style.paddingBottom = "0px";
    }
  }
  checkOut();
});

// clear(data) {
//   data.innerHTML = '';
//this._parentElement.insertAdjacentHTML('afterbegin', markup);
//_parentEl = document.querySelector('.search');
// }
